<?php
session_start();

if(isset($_SESSION['role']))
{
	if(strlen($_SESSION['role']) < 1)
	{
		header("Location: index.php");
		exit;
	}
}
else
{
	header("Location: index.php");
	exit;
}

include("incs/dbcon.inc");

if(isset($_REQUEST['d']))
{
	mysql_query("delete from giftc where gcode='".trim(stripslashes(strip_tags(base64_decode($_REQUEST['d']))))."'") or die(mysql_error());
	
	header("Location: giftcerts.php");
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>OmniPOSS ::</title>
</head>

<body style="font-family:Arial, Helvetica, sans-serif; font-size:12px">
<table width="100%" height="99" border="0" >
  <!--DWLayoutTable-->
  <tr>
    <td height="101" colspan="2" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/banner_r2_c2.png">
      <!--DWLayoutTable-->
      <tr>
        <td width="108" rowspan="2" valign="top"><table width="108" border="0" cellpadding="0" cellspacing="0" background="images/transactions_r1_c2.png">
          <!--DWLayoutTable-->
          <tr>
            <td width="108" height="99">&nbsp;</td>
              </tr>
        </table></td>
        <td width="6" height="74">&nbsp;</td>
        <td width="101" rowspan="2" valign="middle"><img src="images/transactions_r2_c4.png" width="102" height="32" /></td>
        <td width="8">&nbsp;</td>
        <td width="109" rowspan="2" valign="middle"><img src="images/transactions_r2_c7.png" width="109" height="32" /></td>
        <td width="410">&nbsp;</td>
        <td width="107" rowspan="2" valign="top"><a href="settings.php"><img src="images/transactions_r1_c19.png" title="Settings" width="107" height="99" border="0" /></a></td>
        <td width="15">&nbsp;</td>
        <td width="108" rowspan="2" valign="top"><a href="logout.php"><img src="images/transactions_r1_c22.png" title="Logout" width="108" height="99" border="0" /></a></td>
      </tr>
      <tr>
        <td height="25">&nbsp;</td>
        <td>&nbsp;</td>
        <td align="center" valign="middle" style="color:#FFFFFF; font-family:Arial, Helvetica, sans-serif; font-size:12px">Welcome<?php include('incs/head.inc'); ?></td>
        <td>&nbsp;</td>
      </tr>
      
    </table>    </td>
  </tr>
  <tr>
    <td width="108" height="900" valign="top"><?php include('incs/cpanel.inc'); ?>    </td>
    <td width="864" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="864" height="898" valign="top">
            
            <marquee onmouseover='this.stop();' onmouseout='this.start();'direction='left' scrollamount='1' scrolldelay='30' style="color:red">
                <?php include_once("notifications.php"); ?>
            </marquee>
        
        <p align="center"><a href="ncoupon.php"><img src="images/add.gif" border="0" title="Add Coupon" /></a></p>

<h2 align="center">COUPONS</h2>
<table align="center" width="80%">
<th bgcolor="#000000"><font color="#FFFFFF">SNo.</font></th><th bgcolor="#000000"><font color="#FFFFFF">COUPON CODE</font></th><th bgcolor="#000000"><font color="#FFFFFF">COUPON VALUE</font></th><th bgcolor="#000000"><font color="#FFFFFF">COUPON STATUS</font></th><th bgcolor="#000000"><font color="#FFFFFF">TRANSACTION ID</font></th><th bgcolor="#000000"><font color="#FFFFFF">TRANSACTION DATE</font></th><th bgcolor="#000000"><font color="#FFFFFF">DATE CREATED</font></th><th></th>
<?php
$rst = mysql_query("select * from giftc where gtyp='CERT'") or die(mysql_error());
$cnt=0;

while($row = mysql_fetch_array($rst))
{
	$cnt++;
	echo "<tr align='center'><td>$cnt.</td><td>".trim($row['gcode'])."</td><td>".number_format(trim($row['gvalue']),2,'.',',')."</td><td><img src='images/".trim($row['status']).".gif' width='16px' height='16px' /></td><td>".getTrans(trim($row['tran_id']))."</td><td>".trim($row['tdte'])."</td><td>".trim($row['dte'])."</td><td><a href='ecoupons.php?e=".trim(base64_encode($row['gcode']))."'><img src='images/edit.png' title='Edit Coupon Details' border=0 /></a> &nbsp; <a href='coupons.php?d=".trim(base64_encode($row['gcode']))."'><img src='images/del.png' title='Delete Coupon' border=0 /></a></td>";
	echo "<tr><td colspan='8'><hr></td>";
}

function getTrans($c)
{
	switch($c)
	{
		case 0:
		return "<img src='images/1.gif' title='Coupon not used' width='16px' height='16px' />";
		break;
		
		default:
		return "<a href='vw_trans.php?i=".$c."&s=S' title='View Transaction' style='color:blue'>".$c."</a>";
	}
}
?>
        
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</body>
</html>
